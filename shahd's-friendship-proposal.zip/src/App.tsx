import React, { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Music, Music2 } from 'lucide-react';

export default function App() {
  const [noCount, setNoCount] = useState(0);
  const [isAccepted, setIsAccepted] = useState(false);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const bgMusicRef = useRef<HTMLAudioElement | null>(null);

  // Sound effects URLs
  const sounds = {
    pop: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3",
    flee: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
    success: "https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3",
    bg: "https://assets.mixkit.co/music/preview/mixkit-romantic-piano-111.mp3",
  };

  useEffect(() => {
    bgMusicRef.current = new Audio(sounds.bg);
    bgMusicRef.current.loop = true;
    bgMusicRef.current.volume = 0.3;

    return () => {
      if (bgMusicRef.current) {
        bgMusicRef.current.pause();
        bgMusicRef.current = null;
      }
    };
  }, []);

  const toggleMusic = () => {
    if (bgMusicRef.current) {
      if (isMusicPlaying) {
        bgMusicRef.current.pause();
      } else {
        bgMusicRef.current.play().catch(e => console.log("Music play blocked", e));
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };

  const playSound = (url: string) => {
    const audio = new Audio(url);
    audio.volume = 0.4;
    audio.play().catch(e => console.log("Audio play blocked", e));
  };

  const phrases = [
    "", // البداية
    "أنتِ أكيد بتهزري؟ 🤔",
    "طب فكري تاني طيب! 🙄",
    "ليه كده يا شهد؟ 😢",
    "خلاص دي آخر فرصة! ⚠️",
    "يا بنتي بطلي دلع بقى 😂",
    "شهد.. قلبي هيقف! 💔",
    "هعيط والله 😭",
    "ماشي.. براحتك بس فكري!",
    "يا بنتي دوسي نعم وخلاص 🙄"
  ];

  // وظيفة لجعل الزر يهرب بعيداً بشكل سلس جداً
  const flee = useCallback(() => {
    if (noCount < 3) return; // الهروب يبدأ بعد المحاولة الثالثة
    playSound(sounds.flee);

    // حساب حدود الهروب (لا يخرج عن الشاشة)
    const padding = 100;
    const maxWidth = (window.innerWidth / 2) - padding;
    const maxHeight = (window.innerHeight / 2) - padding;

    // توليد إحداثيات عشوائية بعيدة عن المركز
    const newX = (Math.random() - 0.5) * maxWidth * 1.5;
    const newY = (Math.random() - 0.5) * maxHeight * 1.5;

    setNoButtonPos({ x: newX, y: newY });
  }, [noCount]);

  const handleNoClick = () => {
    setNoCount(prev => prev + 1);
    playSound(sounds.pop);
    if (noCount >= 3) flee();
  };

  const handleYesClick = () => {
    playSound(sounds.success);
    setIsAccepted(true);
  };

  // حجم زر "نعم" يكبر قليلاً مع كل محاولة "لا"
  const yesScale = 1 + (noCount * 0.1);

  return (
    <div className="min-h-screen bg-[#fff0f6] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none">
      
      {/* Music Toggle */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        onClick={toggleMusic}
        className="absolute top-6 right-6 z-50 p-3 bg-white/50 backdrop-blur-sm rounded-full shadow-lg text-[#d81b60] hover:bg-white transition-colors"
      >
        {isMusicPlaying ? <Music size={24} /> : <Music2 size={24} className="opacity-50" />}
      </motion.button>
      <AnimatePresence mode="wait">
        {!isAccepted ? (
          <motion.div
            key="question-screen"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex flex-col items-center w-full max-w-lg z-10"
          >
            {/* نص الترحيب العلوي */}
            <p className="text-[#d81b60] font-bold mb-4 opacity-60">أهلاً شهد ياسر ✨</p>

            {/* الأفاتار - يظل ثابتاً وموجوداً دائماً */}
            <motion.div 
              className="relative mb-6"
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            >
              <img 
                src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHpobXp5ZWF2ZHh0Zjh2Z3p5Z3Z5Z3Z5Z3Z5Z3Z5Z3Z5Z3Z5Z3ZpbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/cLS1cfxvGOPVpf9g3y/giphy.gif"
                alt="Cute Chibi"
                className="w-40 h-40 object-contain"
                referrerPolicy="no-referrer"
              />

              {/* الخانة السوداء (فقاعة الكلام) - تظهر بعد أول "لا" */}
              <AnimatePresence>
                {noCount > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0 }}
                    className="absolute -top-16 left-1/2 -translate-x-1/2 bg-black text-white px-4 py-2 rounded-2xl text-sm font-bold whitespace-nowrap shadow-xl"
                  >
                    {phrases[Math.min(noCount, phrases.length - 1)]}
                    {/* مثلث الفقاعة */}
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-black"></div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* السؤال الأساسي */}
            <h1 className="text-3xl font-black text-[#880e4f] text-center mb-10 leading-tight">
              شهد.. هل تقبلين أن <br/> تكوني صديقة لي؟
            </h1>

            {/* منطقة الأزرار */}
            <div className="flex items-center justify-center gap-6 w-full h-24 relative">
              <motion.button
                onClick={handleYesClick}
                style={{ scale: yesScale }}
                whileHover={{ scale: yesScale + 0.05 }}
                whileTap={{ scale: yesScale - 0.05 }}
                className="bg-[#4caf50] text-white font-bold py-3 px-10 rounded-xl shadow-lg hover:bg-[#43a047] transition-colors z-20 cursor-pointer"
              >
                نعم
              </motion.button>

              <motion.button
                onMouseEnter={flee}
                onClick={handleNoClick}
                animate={{ 
                  x: noButtonPos.x, 
                  y: noButtonPos.y 
                }}
                transition={{ 
                  type: "spring", 
                  stiffness: 400, 
                  damping: 25,
                  mass: 0.5 
                }}
                className="bg-[#f44336] text-white font-bold py-3 px-10 rounded-xl shadow-lg hover:bg-[#d32f2f] z-30 touch-none"
              >
                لا
              </motion.button>
            </div>

            {noCount >= 3 && (
              <motion.p 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 0.4 }} 
                className="mt-8 text-[10px] uppercase tracking-widest text-[#ad1457]"
              >
                حاولي تمسكي زر "لا" لو قدرتي 😂
              </motion.p>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="success-screen"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center text-center bg-white/40 backdrop-blur-md p-10 rounded-[40px] shadow-2xl border-4 border-pink-300"
          >
            <motion.img
              src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOWpobXp5ZWF2ZHh0Zjh2Z3p5Z3Z5Z3Z5Z3Z5Z3Z5Z3Z5Z3ZpbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/26FLdmIp6wJr91JAI/giphy.gif"
              alt="Celebration"
              className="w-56 h-56 mb-6"
              animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              referrerPolicy="no-referrer"
            />
            <h1 className="text-4xl font-black text-[#d81b60] mb-4">
              أحلى "نعم" سمعتها يا شهد! 💖
            </h1>
            <p className="text-xl font-bold text-gray-700">كنت عارف إنك ذوق والله 🌸</p>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              onClick={() => {
                setNoCount(0);
                setIsAccepted(false);
                setNoButtonPos({x:0, y:0});
              }}
              className="mt-10 text-[#d81b60] text-sm underline opacity-50 hover:opacity-100"
            >
              إعادة التجربة؟
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* قلوب خلفية عشوائية */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-pink-400"
            initial={{ y: "100vh", x: `${Math.random() * 100}vw` }}
            animate={{ y: "-10vh" }}
            transition={{ duration: 10 + Math.random() * 10, repeat: Infinity, ease: "linear" }}
          >
            ❤️
          </motion.div>
        ))}
      </div>
    </div>
  );
}
